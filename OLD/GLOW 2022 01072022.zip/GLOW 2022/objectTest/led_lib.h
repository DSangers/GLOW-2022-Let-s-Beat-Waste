#ifndef led_lib.h
#define led_lib.h
#include "Arduino.h" 
class MyClass {
public:
  MyClass(int pin);
  void myFunction(int blinkRate);
private:
  int _pin;
};
#endif
