#ifndef Heart_lib_h
#define Heart_lib_h

#include <Servo.h>
#include <arduino.h>

struct Servo{
    Servo myservo;
    
}

bool buttonReadingFunction(int buttonPin);
void servoFunction(int option); 

#endif
