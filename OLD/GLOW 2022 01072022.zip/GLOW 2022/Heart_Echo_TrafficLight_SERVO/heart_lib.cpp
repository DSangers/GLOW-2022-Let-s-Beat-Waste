#include "Heart_lib.h"

//variables for button
int lastButtonState = 0;
unsigned long lastDebounceTime = 0;
unsigned long debounceDelay = 500;

//variables for servo
int s_angle = 0;
int previousAngle = 0;
int pos = 0;

bool buttonReadingFunction(int buttonPin){
  //read button
  int buttonReading = digitalRead(buttonPin);   // check if the pushbutton is pressed. If it is, the buttonState is HIGH:

  // reset the debouncing timer
  if (buttonReading != lastButtonState) {
    lastDebounceTime = millis();
  }

  // save the reading. Next time through the loop, it'll be the lastButtonState:
  lastButtonState = buttonReading;

  // if the the reading has occured longer than dedebounce time update current state
  if ((millis() - lastDebounceTime) > debounceDelay) {
    if (buttonReading == HIGH) {
      return(buttonReading);
    }
    else {
      return(buttonReading);
    }
  }
}

void function_servo_parts(int option) {
  if (option == 1) {
    s_angle = 5;
  }
  else if (option == 2) {
    s_angle = 40;
  }
  else if (option == 3) {
    s_angle = 80;
  }
  else if (option == 4) {
    s_angle = 120;
  }

  if (s_angle < previousAngle) {
    Serial.println("smaller");
    for (int i = previousAngle; i >= s_angle; i--) {
      myservo.write(i);
      Serial.println(i);
      delay(15);
    }
  }
  else if (s_angle == previousAngle) {
    delay(15);
  }
  else if (s_angle > previousAngle) {
    Serial.println("Bigger");
    for (int i = previousAngle; i <= s_angle; i++) {
      myservo.write(i);
      Serial.println(i);
      delay(15);
    }
  }
  previousAngle = s_angle;
}
